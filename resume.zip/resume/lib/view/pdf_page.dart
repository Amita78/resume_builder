import 'dart:io';
import 'dart:typed_data';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pd;
import 'package:fluttertoast/fluttertoast.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:printing/printing.dart';
import '../constant/constants.dart';

class PdfPreviewPage extends StatelessWidget {
  const PdfPreviewPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PDF Preview'),
      ),
      body: PdfPreview(
        build: (context) => makePdf(),
      ),
    );
  }

  Future<Uint8List> makePdf() async {
    final pdf = pd.Document();
    pd.Column buildHeader() {
      return pd.Column(
          crossAxisAlignment: pd.CrossAxisAlignment.start,
          children: [
            pd.Text(
              AppConstants.name,
              style: pd.TextStyle(
                fontSize: 18.0,
                fontWeight: pd.FontWeight.bold,
              ),
            ),
            pd.SizedBox(height: 5.0.h),
            pd.Text(AppConstants.position,
                style: pd.TextStyle(
                  fontSize: 16.0,
                  fontWeight: pd.FontWeight.normal,
                  color: PdfColors.black,
                )),
            pd.SizedBox(height: 5.0.h),
            pd.Row(children: [
              pd.Icon(const pd.IconData(0xe3ab),
                  color: PdfColors.black, size: 20),
              pd.Text(
                AppConstants.location,
                style: const pd.TextStyle(
                  fontSize: 16,
                  color: PdfColors.black,
                ),
              ),
            ]),
          ]);
    }

    pd.Column buildTitle(String title) {
      return pd.Column(
          crossAxisAlignment: pd.CrossAxisAlignment.start,
          children: [
            pd.Text(title.toUpperCase(),
                style: pd.TextStyle(
                  fontSize: 18,
                  fontWeight: pd.FontWeight.bold,
                )),
            pd.Divider(color: PdfColors.purple)
          ]);
    }

    pd.Row buildSkillRow(String title, double level) {
      return pd.Row(children: [
        pd.Expanded(
            flex: 2,
            child: pd.Text(
              title.toUpperCase(),
              textAlign: pd.TextAlign.right,
            )),
        pd.SizedBox(width: 10),
        pd.Expanded(
            flex: 5,
            child: pd.LinearProgressIndicator(
              value: level,
            ))
      ]);
    }

    pd.Row buildExperienceRow(
        String company, String position, String duration) {
      return pd.Row(
        crossAxisAlignment: pd.CrossAxisAlignment.start,
        children: [
          pd.Icon(
            pd.IconData(FontAwesomeIcons.solidCircle.codePoint),
            size: 12.0,
            color: PdfColors.black,
          ),
          pd.SizedBox(width: 10),
          pd.Column(crossAxisAlignment: pd.CrossAxisAlignment.start, children: [
            pd.Text(
              company,
              style: pd.TextStyle(
                  color: PdfColors.black, fontWeight: pd.FontWeight.bold),
            ),
            pd.Text("$position ($duration)")
          ])
        ],
      );
    }

    pd.Widget urlLink(String url, String text) {
      return pd.UrlLink(
        destination: url,
        child: pd.Text(text,
            style: const pd.TextStyle(
              decoration: pd.TextDecoration.underline,
              color: PdfColors.blue,
            )),
      );
    }

    pdf.addPage(pd.MultiPage(
        // theme: pd.ThemeData.withFont(
        //   icons: await PdfGoogleFonts.materialIcons(),
        // ),
        build: (context) {
          return [
            pd.Column(
                crossAxisAlignment: pd.CrossAxisAlignment.start,
                children: [
                  buildHeader(),
                  pd.SizedBox(height: 10),
                  pd.Container(
                      width: double.infinity,
                      padding: const pd.EdgeInsets.all(16),
                      decoration: const pd.BoxDecoration(color: PdfColors.grey),
                      child: pd.Text(AppConstants.headerExp,
                          style: const pd.TextStyle(
                            fontSize: 15,
                          ))),
                  pd.SizedBox(height: 10),
                  buildTitle(AppConstants.title1),
                  pd.SizedBox(height: 5),
                  buildSkillRow(
                      AppConstants.skill1Title, AppConstants.skill1Level),
                  pd.SizedBox(height: 5),
                  buildSkillRow(
                      AppConstants.skill2Title, AppConstants.skill2Level),
                  pd.SizedBox(height: 5),
                  buildSkillRow(
                      AppConstants.skill3Title, AppConstants.skill3Level),
                  pd.SizedBox(height: 5),
                  buildSkillRow(
                      AppConstants.skill4Title, AppConstants.skill4Level),
                  pd.SizedBox(height: 5),
                  buildTitle(AppConstants.title2),
                  buildExperienceRow(
                    AppConstants.experience1Company,
                    AppConstants.experience1Position,
                    AppConstants.experience1Duration,
                  ),
                  buildExperienceRow(
                    AppConstants.experience2Company,
                    AppConstants.experience2Position,
                    AppConstants.experience2Duration,
                  ),
                  pd.SizedBox(
                    height: 10,
                  ),
                  buildTitle(AppConstants.title3),
                  buildExperienceRow(
                    AppConstants.education1College,
                    AppConstants.education1Course,
                    AppConstants.education1Duration,
                  ),
                  buildExperienceRow(
                    AppConstants.education2College,
                    AppConstants.education2Course,
                    AppConstants.education2Duration,
                  ),
                  pd.SizedBox(
                    height: 10.0.h,
                  ),
                  buildTitle(AppConstants.title4),
                  buildExperienceRow(
                    AppConstants.project1Title,
                    AppConstants.project1Description,
                    AppConstants.project1Language,
                  ),
                  buildExperienceRow(
                    AppConstants.project2Title,
                    AppConstants.project2Description,
                    AppConstants.project2Language,
                  ),
                  buildExperienceRow(
                    AppConstants.project3Title,
                    AppConstants.project3Description,
                    AppConstants.project3Language,
                  ),
                  pd.SizedBox(
                    height: 10,
                  ),
                  buildTitle(AppConstants.title5),
                  buildExperienceRow(
                    AppConstants.research1Title,
                    AppConstants.research1Publish,
                    AppConstants.research1ISSN,
                  ),
                  buildExperienceRow(
                    AppConstants.research2Title,
                    AppConstants.research2Publish,
                    AppConstants.research2ISSN,
                  ),
                  pd.SizedBox(
                    height: 10,
                  ),
                  buildTitle(AppConstants.title6),
                  pd.SizedBox(
                    height: 10,
                  ),
                  pd.Row(
                    children: [
                      pd.SizedBox(
                        width: 20,
                      ),
                      pd.Icon(
                        const pd.IconData(0xe3c3),
                        color: PdfColors.black,
                        size: 20,
                      ),
                      pd.SizedBox(
                        width: 5,
                      ),
                      pd.Text(
                        AppConstants.email,
                        style: const pd.TextStyle(
                            fontSize: 16.0,
                            // fontWeight: FontWeight.w500,
                            color: PdfColors.black),
                      ),
                    ],
                  ),
                  pd.SizedBox(
                    height: 5,
                  ),
                  pd.Row(
                    children: [
                      pd.SizedBox(
                        width: 20,
                      ),
                      pd.Icon(
                        pd.IconData(Icons.phone.codePoint),
                        color: PdfColors.black,
                        size: 20,
                      ),
                      pd.SizedBox(
                        width: 5,
                      ),
                      pd.Text(
                        AppConstants.phone,
                        style: const pd.TextStyle(
                            fontSize: 16.0, color: PdfColors.black),
                      ),
                    ],
                  ),
                  pd.SizedBox(
                    height: 10,
                  ),
                  buildTitle(AppConstants.title7),
                  pd.SizedBox(
                    height: 10,
                  ),
                  urlLink(AppConstants.githubUrl, 'GitHub'),
                  pd.SizedBox(
                    height: 10,
                  ),
                  urlLink(AppConstants.linkedInUrl, 'LinkedIn'),
                ])
          ];
        }));

    return pdf.save();
    // final byte =await pdf.save();
    // saveFile(byte, 'Name');
  }

// Future<void> saveFile(data, String name) async {
//   print('Enter');
//   // DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
//   // AndroidDeviceInfo android = await deviceInfo.androidInfo;
//   final status = await Permission.storage.request();
//   if (status.isDenied) {
//     Permission.storage.request();
//     return;
//   }
//   if (status.isGranted) {
//     Directory directory = Directory(
//         'storage/emulated/0/Download'); //! THIS WORKS for android only !!!!!!
//     print(directory.path);
//     File file = await File('${directory.path}/$name.pdf').create();
//     await file.writeAsBytes(data);
//     Fluttertoast.showToast(msg: ' $name Pdf downloaded to ${directory.path}',
//         gravity: ToastGravity.TOP);
//   }
// }
}
