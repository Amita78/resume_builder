import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:resume/constant/constants.dart';
import 'package:resume/view/pdf_page.dart';
import 'package:url_launcher/url_launcher.dart';

class Portfolio extends StatelessWidget {
  const Portfolio({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              onPressed: () async {
                String email = Uri.encodeComponent(AppConstants.email);
                String subject = Uri.encodeComponent('');
                String body = Uri.encodeComponent('');
                Uri mail = Uri.parse('mailto:$email?subject=$subject&body=$body');
                if(await launchUrl(mail)){

                }else{}
              },
              icon: const Icon(
                FontAwesomeIcons.commentDots,
                color: Colors.black54,
              ),
            ),
            IconButton(
              onPressed: () {
                // makePdf();
                Get.to(PdfPreviewPage());
              },
              icon: const Icon(
                Icons.download,
                color: Colors.black,
              ),
            ),
          ],
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(left: 10.0.w, right: 10.0.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              SizedBox(
                height: 10.0.h,
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                ),
                child: const Text(
                  AppConstants.headerExp,
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 15.0),
                ),
              ),
              SizedBox(
                height: 10.0.h,
              ),
              _buildTitle(AppConstants.title1),
              SizedBox(
                height: 10.0.h,
              ),
              _buildSkillRow(
                  AppConstants.skill1Title, AppConstants.skill1Level),
              SizedBox(
                height: 5.0.h,
              ),
              _buildSkillRow(
                  AppConstants.skill2Title, AppConstants.skill2Level),
              SizedBox(
                height: 5.0.h,
              ),
              _buildSkillRow(
                  AppConstants.skill3Title, AppConstants.skill3Level),
              SizedBox(
                height: 10.0.h,
              ),
              _buildSkillRow(
                  AppConstants.skill4Title, AppConstants.skill4Level),
              SizedBox(
                height: 5.0.h,
              ),
              _buildTitle(AppConstants.title2),
              _buildExperienceRow(
                AppConstants.experience1Company,
                AppConstants.experience1Position,
                AppConstants.experience1Duration,
              ),
              _buildExperienceRow(
                AppConstants.experience2Company,
                AppConstants.experience2Position,
                AppConstants.experience2Duration,
              ),
              SizedBox(
                height: 10.0.h,
              ),
              _buildTitle(AppConstants.title3),
              _buildExperienceRow(
                AppConstants.education1College,
                AppConstants.education1Course,
                AppConstants.education1Duration,
              ),
              _buildExperienceRow(
                AppConstants.education2College,
                AppConstants.education2Course,
                AppConstants.education2Duration,
              ),
              SizedBox(
                height: 10.0.h,
              ),
              _buildTitle(AppConstants.title4),
              _buildExperienceRow(AppConstants.project1Title, AppConstants.project1Description,
                  AppConstants.project1Language,),
              _buildExperienceRow(AppConstants.project2Title, AppConstants.project2Description,
                AppConstants.project2Language,),
              _buildExperienceRow(
                AppConstants.project3Title, AppConstants.project3Description,
                AppConstants.project3Language,),
              SizedBox(
                height: 10.0.h,
              ),
              _buildTitle(AppConstants.title5),
              _buildExperienceRow(AppConstants.research1Title,
                  AppConstants.research1Publish,AppConstants.research1ISSN,),
              _buildExperienceRow(
                AppConstants.research2Title,
                AppConstants.research2Publish,AppConstants.research2ISSN,),
              SizedBox(
                height: 10.0.h,
              ),
              _buildTitle(AppConstants.title6),
              SizedBox(
                height: 10.0.h,
              ),
              Row(
                children: [
                  SizedBox(
                    width: 20.0.w,
                  ),
                  const Icon(
                    Icons.mail,
                    color: Colors.black54,
                    size: 20,
                  ),
                  SizedBox(
                    width: 5.0.w,
                  ),
                  const Text(
                    AppConstants.email,
                    style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                        color: Colors.black54),
                  ),
                ],
              ),
              SizedBox(
                height: 5.0.h,
              ),
              Row(
                children: [
                  SizedBox(
                    width: 20.0.w,
                  ),
                  const Icon(
                    Icons.phone,
                    color: Colors.black54,
                    size: 20,
                  ),
                  SizedBox(
                    width: 5.0.w,
                  ),
                  const Text(
                  AppConstants.phone,
                    style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                        color: Colors.black54),
                  ),
                ],
              ),
              SizedBox(
                height: 10.0.h,
              ),
              _buildTitle(AppConstants.title7),
              SizedBox(
                height: 10.0.h,
              ),
              _buildSocialRow(),
            ],
          ),
        ));
  }

  Future _launchUrl(String url) async {
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    } else {
      throw 'Could not launch $url';
    }
  }

  Widget _buildSocialRow() {
    return Row(
      children: [
        SizedBox(
          width: 5.0.w,
        ),
        // IconButton(
        //     onPressed: () {
        //
        //     },
        //     icon: Icon(
        //       FontAwesomeIcons.facebookF,
        //       color: Colors.indigo,
        //       size: 18.0.sp,
        //     )),
        SizedBox(
          width: 5.0.w,
        ),
        IconButton(
            onPressed: () async {
              _launchUrl(AppConstants.githubUrl);
            },
            icon: const Icon(
              FontAwesomeIcons.github,
              color: Colors.indigo,
              size: 18.0,
            )),
        SizedBox(
          width: 5.0.w,
        ),
        IconButton(
            onPressed: () async {
              _launchUrl(
                  AppConstants.linkedInUrl);
            },
            icon: const Icon(
              FontAwesomeIcons.linkedin,
              color: Colors.indigo,
              size: 18.0,
            ))
      ],
    );
  }

  Widget _buildExperienceRow(String company, String position, String duration) {
    return ListTile(
      leading: const Icon(
        FontAwesomeIcons.solidCircle,
        size: 12.0,
        color: Colors.black54,
      ),
      title: Text(
        company,
        style:
            const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
      ),
      subtitle: Text("$position ($duration)"),
    );
  }

  Widget _buildSkillRow(String title, double level) {
    return Row(
      children: [
        Expanded(
            flex: 2,
            child: Text(
              title.toUpperCase(),
              textAlign: TextAlign.right,
            )),
        SizedBox(
          width: 10.0.w,
        ),
        Expanded(
          flex: 5,
          child: LinearProgressIndicator(
            value: level,
          ),
        ),
      ],
    );
  }

  Widget _buildTitle(String title) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title.toUpperCase(),
          style: const TextStyle(
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        const Divider(
          color: Colors.deepPurple,
        ),
      ],
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          AppConstants.name,
          style: TextStyle(
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(
          height: 5.0.h,
        ),
        const Text(
          AppConstants.position,
          style: TextStyle(
            fontSize: 16.0,
            fontWeight: FontWeight.w500,
            color: Colors.black54,
          ),
        ),
        SizedBox(
          height: 5.0.h,
        ),
        const Row(
          children: [
            Icon(
              Icons.location_on,
              color: Colors.black54,
              size: 20,
            ),
            Text(
             AppConstants.location,
              style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w500,
                  color: Colors.black54),
            ),
          ],
        ),
      ],
    );
  }
}
